

set -Ux GIT_EDITOR (command -v nvim || command -v vim || command -v micro || command -v nano || command -v vi)
set -Ux EDITOR (command -v nvim || command -v vim || command -v micro || command -v nano || command -v vi)
#set -Ux EDITOR (command -v micro || command -v nano || command -v nvim || command -v vim || command -v vi)
set -Ux VISUAL (command -v nvim || command -v vim || command -v micro || command -v nano || command -v vi)
set -Ux SUDO_EDITOR (command -v nvim || command -v vim || command -v micro || command -v nano || command -v vi)

set current_tty (tty)  
if not string match -q "/dev/pts/*" $current_tty  
    set -g is_bare_tty true  
    # Действия для голого tty, например, настройка минималистичного промта
    #ter-v16n cyr-sun16 LatGrkCyr-8x16 LatArCyrHeb-16 lat9u-16
    setfont ter-v16n
else  
    set -g is_bare_tty false  
    # Действия для терминала в графической оболочке, например, включение цветового оформления  
end  


if status is-interactive
    # Commands to run in interactive sessions can go here
end

function update-grub
    sudo grub-mkconfig -o /boot/grub/grub.cfg
end



# Включаем sudo-rs alias при старте
if not functions -q sudo
    function sudo
        command sudo-rs $argv
    end
end

# Помечаем статус для prompt
set -U __sudo_using_rs 1











