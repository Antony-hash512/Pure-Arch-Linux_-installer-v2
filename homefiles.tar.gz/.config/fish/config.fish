fish_add_path ~/bin/bin

set -Ux GIT_EDITOR (command -v nvim || command -v vim || command -v micro || command -v nano || command -v vi)
set -Ux EDITOR (command -v micro || command -v nano || command -v nvim || command -v vim || command -v vi)
set -Ux VISUAL (command -v nvim || command -v vim || command -v micro || command -v nano || command -v vi)
set -Ux SUDO_EDITOR (command -v nvim || command -v vim || command -v micro || command -v nano || command -v vi)


if status is-interactive
    # Commands to run in interactive sessions can go here
end

function update-grub
    sudo grub-mkconfig -o /boot/grub/grub.cfg
end
