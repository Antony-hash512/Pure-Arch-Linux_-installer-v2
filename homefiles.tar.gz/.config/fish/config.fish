fish_add_path ~/bin/bin

if status is-interactive
    # Commands to run in interactive sessions can go here
end

function update-grub
    sudo grub-mkconfig -o /boot/grub/grub.cfg
end
