function fish_right_prompt
    if set -q __sudo_using_rs
        set_color yellow
        echo -n '🦀'
        set_color normal
		#else
		#echo -n '🐟'
    end
end

