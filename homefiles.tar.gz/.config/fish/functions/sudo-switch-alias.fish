
function sudo-switch-alias
    if set -q __sudo_using_rs
        set -eU __sudo_using_rs
        functions -e sudo
        echo "🔁 Переключено на оригинальный sudo"
    else
        function sudo
            command sudo-rs $argv
        end
        set -U __sudo_using_rs 1
        echo "🔁 Переключено на sudo-rs (через alias)"
    end
end

