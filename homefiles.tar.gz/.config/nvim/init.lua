-- Включение подсветки синтаксиса (не требуется в Neovim, включено по умолчанию)
-- vim.cmd("syntax on")

-- Включение номеров строк
vim.opt.number = true

-- Отображение скрытых символов
vim.opt.list = true
vim.opt.listchars = { tab = "» »", space = "·" }

-- Подключение системного буфера обмена
vim.opt.clipboard = "unnamedplus"

-- Настройки табуляции
vim.opt.tabstop = 4        -- Отображение табуляции как 4 пробела
vim.opt.softtabstop = 0    -- Отключение автоматического замещения табов пробелами
vim.opt.shiftwidth = 4     -- Размер отступа при сдвигах (>> и <<)
vim.opt.expandtab = false  -- Использовать реальные табуляции (\t), а не пробелы

-- Загрузка packer
vim.cmd [[packadd packer.nvim]]
--  paru -S nvim-packer-git
-- :PackerInstall -- установка плагинов
-- :PackerSync -- их обновление
require('packer').startup(function(use)
  use 'wbthomason/packer.nvim'     -- сам packer
  use 'github/copilot.vim'         -- copilot
  use 'nvim-tree/nvim-tree.lua'
  use 'nvim-tree/nvim-web-devicons' -- иконки
  use 'nvim-lualine/lualine.nvim'      -- статусбар внизу
  use 'akinsho/bufferline.nvim'        -- вкладки вверху (как в VSCode)
  use "folke/tokyonight.nvim"
  use { "catppuccin/nvim", as = "catppuccin" }
end)

-- Автокоманда: пересобрать packer при изменении init.lua
vim.cmd [[
  augroup packer_user_config
    autocmd!
    autocmd BufWritePost init.lua source <afile> | PackerCompile
  augroup end
]]

-- nvim-web-devicons
pcall(function()
  require('nvim-web-devicons').setup()
end)

-- nvim-tree
pcall(function()
  require('nvim-tree').setup()
end)
vim.keymap.set('n', '<C-n>', ':NvimTreeToggle<CR>', { noremap = true, silent = true })

-- Copilot
vim.g.copilot_no_tab_map = true
vim.g.copilot_assume_mapped = true
vim.api.nvim_set_keymap("i", "<C-j>", 'copilot#Accept("<CR>")', {
  expr = true,
  silent = true,
  noremap = true,
})

-- lualine
pcall(function()
  require('lualine').setup {
    options = {
      theme = 'auto',
      icons_enabled = true,
      section_separators = '',
      component_separators = '',
      disabled_filetypes = {
        statusline = {},
        winbar = {},
      },
      always_divide_middle = true,
      globalstatus = false,
    },
    sections = {
      lualine_a = {'mode'},
      lualine_b = {'branch'},
      lualine_c = {'filename'},
      lualine_x = {'encoding', 'fileformat', 'filetype'},
      lualine_y = {
        function()
          return '🎨' .. (vim.g.colors_name or 'default')
        end
      },
      lualine_z = {'location'}
    }
  }
end)
-- bufferline
pcall(function()
  require('bufferline').setup {}
end)
vim.keymap.set('n', '<Tab>', ':BufferLineCycleNext<CR>', { noremap = true, silent = true })
vim.keymap.set('n', '<S-Tab>', ':BufferLineCyclePrev<CR>', { noremap = true, silent = true })

--print(vim.g.colors_name)

-- Тёмная и светлая темы
vim.g.catppuccin_flavour = "latte" -- светлая версия
require("catppuccin").setup()
vim.cmd.colorscheme("catppuccin")

local dark_theme = "tokyonight"
local light_theme = "catppuccin"


local function set_theme_by_time()
  local hour = tonumber(os.date("%H"))
  if hour >= 8 and hour < 20 then
    vim.o.background = "light"
    vim.g.catppuccin_flavour = "latte"
    require("catppuccin").setup()
    vim.cmd.colorscheme("catppuccin")
  else
    vim.o.background = "dark"
    vim.cmd.colorscheme("tokyonight")
  end
end


-- Вызов при запуске
set_theme_by_time()

-- Переключение по F5
vim.keymap.set('n', '<F5>', function()
  if vim.o.background == "dark" then
    vim.o.background = "light"
    vim.g.catppuccin_flavour = "latte"
    pcall(function()
      require("catppuccin").setup()
    end)
    vim.cmd.colorscheme(light_theme)
  else
    vim.o.background = "dark"
    vim.cmd.colorscheme(dark_theme)
  end
  print("🌗 Theme: " .. vim.o.background)
end, { noremap = true, silent = true })

