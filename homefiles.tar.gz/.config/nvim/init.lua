-- Включение подсветки синтаксиса (не требуется в Neovim, включено по умолчанию)
-- vim.cmd("syntax on")

-- Включение номеров строк
vim.opt.number = true

-- Включение отображения скрытых символов (listchars)
vim.opt.list = true
vim.opt.listchars = { tab = "» »", space = "·" }

-- Подключение системного буфера обмена
vim.opt.clipboard = "unnamedplus"

-- Настройки табуляции
vim.opt.tabstop = 4        -- Отображение табуляции как 4 пробела
vim.opt.softtabstop = 0    -- Отключение автоматического замещения табов пробелами
vim.opt.shiftwidth = 4     -- Размер отступа при сдвигах (>> и <<)
vim.opt.expandtab = false  -- Использовать реальные табуляции (\t), а не пробелы
