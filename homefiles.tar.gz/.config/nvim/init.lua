-- Включение подсветки синтаксиса (не требуется в Neovim, включено по умолчанию)
-- vim.cmd("syntax on")

-- Включение номеров строк
vim.opt.number = true

-- Отображение скрытых символов
vim.opt.list = true
vim.opt.listchars = { tab = "» »", space = "·" }

-- Подключение системного буфера обмена
vim.opt.clipboard = "unnamedplus"

-- Настройки табуляции
vim.opt.tabstop = 4        -- Отображение табуляции как 4 пробела
vim.opt.softtabstop = 0    -- Отключение автоматического замещения табов пробелами
vim.opt.shiftwidth = 4     -- Размер отступа при сдвигах (>> и <<)
vim.opt.expandtab = false  -- Использовать реальные табуляции (\t), а не пробелы

-- Загрузка packer
vim.cmd [[packadd packer.nvim]]
--  paru -S nvim-packer-git
-- :PackerInstall -- установка плагинов
-- :PackerSync -- их обновление
require('packer').startup(function(use)
  use 'wbthomason/packer.nvim'     -- сам packer
  use 'github/copilot.vim'         -- copilot
  use 'nvim-tree/nvim-tree.lua'
  use 'nvim-tree/nvim-web-devicons' -- иконки
  use 'nvim-lualine/lualine.nvim'      -- статусбар внизу
  use 'akinsho/bufferline.nvim'        -- вкладки вверху (как в VSCode)
end)

-- Автокоманда: пересобрать packer при изменении init.lua
vim.cmd [[
  augroup packer_user_config
    autocmd!
    autocmd BufWritePost init.lua source <afile> | PackerCompile
  augroup end
]]

-- nvim-web-devicons
pcall(function()
  require('nvim-web-devicons').setup()
end)

-- nvim-tree
pcall(function()
  require('nvim-tree').setup()
end)
vim.keymap.set('n', '<C-n>', ':NvimTreeToggle<CR>', { noremap = true, silent = true })

-- Copilot
vim.g.copilot_no_tab_map = true
vim.g.copilot_assume_mapped = true
vim.api.nvim_set_keymap("i", "<C-j>", 'copilot#Accept("<CR>")', {
  expr = true,
  silent = true,
  noremap = true,
})

-- lualine
pcall(function()
  require('lualine').setup {
    options = {
      theme = 'auto',
      icons_enabled = true,
      section_separators = '',
      component_separators = '',
    }
  }
end)

-- bufferline
pcall(function()
  require('bufferline').setup {}
end)
vim.keymap.set('n', '<Tab>', ':BufferLineCycleNext<CR>', { noremap = true, silent = true })
vim.keymap.set('n', '<S-Tab>', ':BufferLineCyclePrev<CR>', { noremap = true, silent = true })

