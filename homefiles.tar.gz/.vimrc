syntax on
set number
