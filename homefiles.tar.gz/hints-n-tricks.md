Basic:
---------------------------------------------------------------------------------------------------------------------
* Use <Ctrl>+<Alt>+C and <Ctrl>+<Alt>+V in the terminal `alacritty` instead <Ctrl>+C and <Ctrl>+V to copy and past.

* Hotkeys:
 * <Ctrl>+<Alt>+T opens the terminal
 * <Win>+E opens the gui file manager thunar
 * <Ctrl>+<Alt>+F opens the cli file manager mc
 * <Ctrl>+<Alt>+H opens htop the system monitor
 * <Ctrl>+<Alt>+G opens the gimp (if it has been installed)
 
 
#TODO: добавить команду установки времени
Включение синхронизации времени:
sudo timedatectl set-ntp true
Отключение синхронизации времени:
sudo timedatectl set-ntp false
Установка времени:
sudo date --set="YYYY-MM-DD HH:MM:SS"
Замените YYYY-MM-DD HH:MM:SS на нужные дату и время.
Настроить системное время на локальное (для совместной работы c Windows):
sudo timedatectl set-local-rtc 1 --adjust-system-clock
Просмотр настроек времени:
timedatectl




tar -cf - my_folder/ | 7z a -mx=9 -si my_archive.tar.7z
Пояснения к команде:

    tar -cf - my_folder/: команда tar создает архив из содержимого директории my_folder и выводит его в стандартный поток вывода (- после -cf означает вывод в stdout, а не в файл).
    |: оператор pipe передает вывод одной команды (в данном случае tar) на вход другой команды (7z).
    7z a -mx=9 -si my_archive.tar.7z: команда 7z создает архив .7z, беря данные из стандартного ввода (-si), с максимальным уровнем сжатия (-mx=9). Имя создаваемого архива — my_archive.tar.7z.


Advanced:
---------------------------------------------------------------------------------------------------------------------
* Run the command:
sudo EDITOR='sed -i "s/^#%supersudo ALL=(ALL:ALL) NOPASSWD: ALL/%supersudo ALL=(ALL:ALL) NOPASSWD: ALL/"' visudo
to get opportunity use sudo without your password
for undo this run:
sudo EDITOR='sed -i "s/^%supersudo ALL=(ALL:ALL) NOPASSWD: ALL/#%supersudo ALL=(ALL:ALL) NOPASSWD: ALL/"' visudo

 
