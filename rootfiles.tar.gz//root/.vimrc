syntax on
set number
set list
set listchars=tab:\ »,space:·
set clipboard=unnamedplus



